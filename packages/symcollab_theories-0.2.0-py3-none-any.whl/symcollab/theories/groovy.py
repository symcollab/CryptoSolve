"""
For an assignment of mine.
"""
from copy import deepcopy
from typing import List
from symcollab.algebra import Variable
from symcollab.theories import Connective, Exists, \
    ForAll, Formula, Not, Predicate


def is_groovy(
    f: Formula,
    available_variables: List[Variable],
    relations: List[Predicate]
    ):
    """
    Decide whether or not a first
    order statement is part of the
    Groovy language or not.

    We do this by starting from the root
    of the formula and recursing down to
    the atomic formula base case.
    """
    # Base Case: Check Atomic Formulas
    if isinstance(f, Predicate):
        # f must be in our relations list
        if f.relation not in relations:
            return False
        # Check placement of variables
        reversed_variables = list(reversed(available_variables))
        for position, variable in enumerate(reversed(f.args)):
            if variable != reversed_variables[position]:
                return False
        return True

    # Not Case 
    if isinstance(f, Not):
        return is_groovy(f.subformula, available_variables, relations)
    
    # Connectives Case (And/Or/Implies/Iff)
    if isinstance(f, Connective):
        return is_groovy(f.f0, available_variables, relations) \
            and is_groovy(f.f1, available_variables, relations)
    
    # Exists/ForAll: Add the bounded variable 
    if isinstance(f, (Exists, ForAll)):
        bound_variable = f.bound_variable

        # Add the bound variable to the copied variable list
        new_avil_var = deepcopy(available_variables)
        new_avil_var.append(bound_variable)

        return is_groovy(f.subformula, new_avil_var, relations)
    
    print(f)
    raise ValueError(f"The formula {type(f)} is not in the FOL language.")


