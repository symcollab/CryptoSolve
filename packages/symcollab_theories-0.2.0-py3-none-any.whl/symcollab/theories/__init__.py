"""Automated Reasoning Library"""
from .predicate import *
from .propositional import *
